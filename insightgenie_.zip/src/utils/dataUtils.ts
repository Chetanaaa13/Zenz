import { SalesData, GenericData } from "../types";
import Papa from 'papaparse';
import * as XLSX from 'xlsx';

export const parseFile = async (file: File): Promise<GenericData[]> => {
  const extension = file.name.split('.').pop()?.toLowerCase();

  if (extension === 'csv') {
    return new Promise((resolve, reject) => {
      Papa.parse(file, {
        header: true,
        dynamicTyping: true,
        skipEmptyLines: true,
        complete: (results) => resolve(results.data as GenericData[]),
        error: (error) => reject(error)
      });
    });
  } else if (extension === 'xlsx' || extension === 'xls') {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const data = new Uint8Array(e.target?.result as ArrayBuffer);
          const workbook = XLSX.read(data, { type: 'array' });
          const firstSheetName = workbook.SheetNames[0];
          const worksheet = workbook.Sheets[firstSheetName];
          const jsonData = XLSX.utils.sheet_to_json(worksheet);
          resolve(jsonData as GenericData[]);
        } catch (error) {
          reject(error);
        }
      };
      reader.onerror = (error) => reject(error);
      reader.readAsArrayBuffer(file);
    });
  } else if (extension === 'json') {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const jsonData = JSON.parse(e.target?.result as string);
          resolve(Array.isArray(jsonData) ? jsonData : [jsonData]);
        } catch (error) {
          reject(error);
        }
      };
      reader.onerror = (error) => reject(error);
      reader.readAsText(file);
    });
  } else {
    throw new Error('Unsupported file format');
  }
};

export const aggregateData = (data: any[], xAxis: string, yAxis: string, filters?: any) => {
  if (!data || data.length === 0) return [];
  let filteredData = [...data];

  if (filters) {
    Object.keys(filters).forEach(key => {
      const filterValues = filters[key];
      if (Array.isArray(filterValues) && filterValues.length > 0) {
        // Try to match filter key with data properties (case-insensitive)
        const dataKey = Object.keys(data[0]).find(k => k.toLowerCase() === key.toLowerCase().replace(/s$/, ''));
        if (dataKey) {
          filteredData = filteredData.filter(d => filterValues.includes(d[dataKey]));
        }
      }
    });
    
    if (filters.dateRange) {
      const dateKey = Object.keys(data[0]).find(k => k.toLowerCase().includes('date'));
      if (dateKey) {
        if (filters.dateRange.start) {
          filteredData = filteredData.filter(d => d[dateKey] >= filters.dateRange.start);
        }
        if (filters.dateRange.end) {
          filteredData = filteredData.filter(d => d[dateKey] <= filters.dateRange.end);
        }
      }
    }
  }

  const map = new Map<string, number>();
  
  filteredData.forEach(item => {
    let key = String(item[xAxis] || 'Unknown');
    
    if (xAxis.toLowerCase().includes('date') && key.length >= 7) {
      key = key.substring(0, 7); // YYYY-MM
    }
    
    const value = Number(item[yAxis]) || 0;
    map.set(key, (map.get(key) || 0) + value);
  });

  return Array.from(map.entries())
    .map(([name, value]) => ({ name, value }))
    .sort((a, b) => {
      // Try numeric sort if both are numbers
      const numA = Number(a.name);
      const numB = Number(b.name);
      if (!isNaN(numA) && !isNaN(numB)) return numA - numB;
      return a.name.localeCompare(b.name);
    });
};

export const calculateMetrics = (data: any[], filters?: any) => {
  if (!data || data.length === 0) return [];
  let filteredData = [...data];

  // Simple filter application (similar to aggregateData)
  if (filters) {
    Object.keys(filters).forEach(key => {
      const filterValues = filters[key];
      if (Array.isArray(filterValues) && filterValues.length > 0) {
        const dataKey = Object.keys(data[0]).find(k => k.toLowerCase() === key.toLowerCase().replace(/s$/, ''));
        if (dataKey) {
          filteredData = filteredData.filter(d => filterValues.includes(d[dataKey]));
        }
      }
    });
  }

  // Try to find a numeric column for "Total"
  const numericCols = Object.keys(data[0]).filter(k => typeof data[0][k] === 'number');
  const primaryMeasure = numericCols.find(k => k.toLowerCase().includes('revenue') || k.toLowerCase().includes('amount') || k.toLowerCase().includes('sales')) || numericCols[0];

  const totalValue = primaryMeasure ? filteredData.reduce((sum, item) => sum + (Number(item[primaryMeasure]) || 0), 0) : 0;
  const count = filteredData.length;
  const avg = count > 0 ? totalValue / count : 0;
  
  const metrics = [];
  if (primaryMeasure) {
    metrics.push({ label: `Total ${primaryMeasure}`, value: totalValue, prefix: primaryMeasure.toLowerCase().includes('revenue') ? "$" : "" });
  }
  metrics.push({ label: "Total Records", value: count });
  if (primaryMeasure) {
    metrics.push({ label: `Avg ${primaryMeasure}`, value: avg.toFixed(2), prefix: primaryMeasure.toLowerCase().includes('revenue') ? "$" : "" });
  }
  metrics.push({ label: "Analysis Confidence", value: "98", suffix: "%" });

  return metrics;
};
