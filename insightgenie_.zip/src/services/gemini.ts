import { GoogleGenAI, Type } from "@google/genai";

let aiInstance: GoogleGenAI | null = null;

const getAi = () => {
  if (!aiInstance) {
    aiInstance = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });
  }
  return aiInstance;
};

export const getDashboardStructure = async (query: string, dataSample?: any[]) => {
  const ai = getAi();
  const sampleText = dataSample ? `Here is a sample of the data columns and types: ${JSON.stringify(dataSample[0])}` : "";
  
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `Analyze the following user query for a business intelligence dashboard: "${query}". 
    ${sampleText}
    Based on the query and the available data columns, suggest a dashboard layout including:
    1. A list of 3-4 KPI metrics.
    2. A list of 2-3 charts (Bar, Line, Pie, or Area).
    3. For each chart, specify the X-axis (dimension) and Y-axis (measure) using the EXACT column names from the data sample if provided.
    
    Return the response as a JSON object.`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          metrics: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                label: { type: Type.STRING },
                key: { type: Type.STRING },
                prefix: { type: Type.STRING },
                suffix: { type: Type.STRING },
              },
              required: ["label", "key"],
            },
          },
          charts: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                title: { type: Type.STRING },
                type: { type: Type.STRING, enum: ["bar", "line", "pie", "area"] },
                xAxis: { type: Type.STRING },
                yAxis: { type: Type.STRING },
              },
              required: ["title", "type", "xAxis", "yAxis"],
            },
          },
          filters: {
            type: Type.OBJECT,
            properties: {
              regions: { type: Type.ARRAY, items: { type: Type.STRING } },
              categories: { type: Type.ARRAY, items: { type: Type.STRING } },
              dateRange: {
                type: Type.OBJECT,
                properties: {
                  start: { type: Type.STRING },
                  end: { type: Type.STRING },
                }
              }
            }
          },
          insights: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
          }
        },
        required: ["metrics", "charts", "insights"],
      },
    },
  });

  return JSON.parse(response.text);
};

export const getAIAnalystResponse = async (query: string, dataSummary: string) => {
  const ai = getAi();
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `You are an expert business data analyst. The user is asking: "${query}". 
    Here is a summary of the data: ${dataSummary}.
    Provide a concise, insightful answer.`,
  });

  return response.text;
};
